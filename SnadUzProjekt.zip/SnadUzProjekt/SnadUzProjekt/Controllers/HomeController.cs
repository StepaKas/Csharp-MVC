﻿using AuctionSystem.ORM.Oracle;
using KonzolaCore.Database;
using KonzolaCore.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using SnadUzProjekt.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace SnadUzProjekt.Controllers
{
    
    public class HomeController : Controller
    {
        public static ICollection<Worker> workers = new List<Worker>();
        public static GenericController genericControler = new GenericController();
        private static Worker activeUser = new Worker();   

        public  HomeController([FromServices] GenericController gc)
        {
            genericControler = gc;

        }
        public IActionResult Workers()
        {
            ViewBag.workers = workers;
            return View();
        }
        [HttpPost]
        public IActionResult Workers(string? Search)
        {

            if (Search == "" || Search == null)
            {
                return Workers();
            }
            ViewBag.workers = workers.Where(x => x.Name.Contains(Search));
            return View();
        }

        public IActionResult WorkerDetail(int Id)
        {

            ViewBag.worker = workers.Where(x => x.Id == Id).First();
            return View();
        }

        public async Task<IActionResult> WorkerDelete(int Id)
        {


            await genericControler.DeleteAsync(Id, new Worker { });
            workers = await genericControler.GetAllAsync(new Worker { });
            return View();
        }

        public IActionResult WorkerUpdate(int Id)
        {

            List<SelectListItem> optionsPosition = new List<SelectListItem>(){
                new SelectListItem("Waiter", "Waiter"),
                new SelectListItem("Cook", "Cook"),
                new SelectListItem("Cleaner", "Cleaner")
            };
            List<SelectListItem> optionsRole = new List<SelectListItem>(){
                new SelectListItem("Boss", "Boss"),
                new SelectListItem("Worker", "Worker")
            };
            ViewBag.PositionOptions = optionsPosition;
            ViewBag.RoleOptions = optionsRole;
            var wor = workers.FirstOrDefault(x => x.Id == Id);
            ViewBag.worker = wor;
            return View(wor);
        }
        [HttpPost]
        public async Task<IActionResult> WorkerUpdate(Worker wor)
        {
            List<SelectListItem> optionsPosition = new List<SelectListItem>(){
                new SelectListItem("Waiter", "Waiter"),
                new SelectListItem("Cook", "Cook"),
                new SelectListItem("Cleaner", "Cleaner")
            };
            List<SelectListItem> optionsRole = new List<SelectListItem>(){
                new SelectListItem("Boss", "Boss"),
                new SelectListItem("Worker", "Worker"),
            };
            ViewBag.PositionOptions = optionsPosition;
            ViewBag.RoleOptions = optionsRole;
            if (!(wor.Name != null && wor.Surname != null && wor.Email != null && wor.My_password != null && wor.Date_of_Birth != null && wor.Position != null && wor.Role != null))
            {
                var wor2 = workers.FirstOrDefault(x => x.Id == wor.Id);
                ViewBag.worker = wor2;
                return View();
            }
            await genericControler.UpdateAsync((int)wor.Id, wor);
            workers = await genericControler.GetAllAsync(new Worker { });
            ViewBag.worker = workers.FirstOrDefault(x => x.Id == wor.Id);
            return View();
        }
        public  IActionResult Index()
        {
            
            var wor =  CurrentUser();
            ViewBag.UserName = wor.Name;
            ViewBag.UserLName = wor.Surname;
            ViewBag.UserRole = wor.Role;
            return View();
        }

        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Login(Worker worker)
        {

            workers = await genericControler.GetAllAsync(new Worker { });
            var wor = workers.FirstOrDefault(x => x.My_password == worker.My_password && x.Email == worker.Email);
            if (wor != null)
            {
                activeUser = wor;
                var data = Encoding.UTF8.GetBytes($"{wor.Email},{wor.My_password}");
                this.HttpContext.Session.Set("user", data);
                return RedirectToAction("Index", "Home");
            }

            return View();
        }
        public IActionResult WorkerCreate()
        {
            List<SelectListItem> optionsPosition = new List<SelectListItem>(){
                new SelectListItem("Waiter", "Waiter"),
                new SelectListItem("Cook", "Cook"),
                new SelectListItem("Cleaner", "Cleaner")
            };
            List<SelectListItem> optionsRole = new List<SelectListItem>(){
                new SelectListItem("Boss", "Boss"),
                new SelectListItem("Worker", "Worker"),

            };

            ViewBag.PositionOptions = optionsPosition;
            ViewBag.RoleOptions = optionsRole;

            return View();
        }
        [HttpPost]
        public async Task<IActionResult> WorkerCreate(Worker wor)
        {

            if (!(wor.Name != null && wor.Surname != null && wor.Email != null && wor.My_password != null && wor.Date_of_Birth != null && wor.Position != null && wor.Role != null))
            {

                return View();
            }
            await genericControler.InsertAsync( wor);
            workers = await genericControler.GetAllAsync(new Worker { });
            ViewBag.worker = workers.FirstOrDefault(x => x.Id == wor.Id);
            return RedirectToAction("Workers", "Home");
        }
        private Worker CurrentUser()
        {
            
            if (this.HttpContext.Session.TryGetValue("user", out byte[] data2))
            {

                List<string> list = new List<string>();
                string txt = Encoding.UTF8.GetString(data2);
                if (txt == "")
                {
                    return new Worker { };
                }
                list = txt.Split(',').ToList();
                var wor = workers.FirstOrDefault(x => x.My_password == list[1] && x.Email == list[0]);

                return wor;
            }
            return new Worker { };

        }


        public IActionResult Logout()
        {
            activeUser = null;
  
            this.HttpContext.Session.Clear();
            return RedirectToAction("Login", "Home");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }


        public IActionResult GetJson()
        {
     

            if (CurrentUser().Role != "Boss")
            {
                return RedirectToAction("NoRights", "Home");
            }
            return new JsonResult(workers);
        }
        public IActionResult GetXml()
        {

            if (CurrentUser().Role != "Boss")
            {
                return RedirectToAction("NoRights", "Home");
            }


            using MemoryStream memoryStream = new MemoryStream();
            XmlSerializer xmlSerializer = new XmlSerializer(typeof( List<Worker>));

            xmlSerializer.Serialize(memoryStream, new List<Worker>(workers) { });
            string xml = Encoding.UTF8.GetString(memoryStream.ToArray());


            return new ContentResult(){
                Content = xml,
                ContentType = "text/xml"
            };
        }
        public IActionResult NoRights()
        {
            return View();
        }

        public async Task<IActionResult> Shifts()
        {
            ViewBag.shifts = await genericControler.GetAllAsync(new Shift() { });
            int userId = decimal.ToInt32(CurrentUser().Id) ;
            var shifts = await genericControler.GetAllWorkersShiftsAsync(userId, new Shift() { });
            ViewBag.userShifts = shifts;
            ViewBag.userId = userId;
            //ViewBag.shifts = await genericControler.GetAllAsync(new Shift { });
            return View();
        }

        public async Task<IActionResult> SignToShift(int workerId, int shiftId, bool is_in)
        {
            if (is_in)
            {
                await genericControler.DeleteAsync(workerId, shiftId);
            }
            else
            {
                await genericControler.InsertLoginAsync(new Worker_is_logged_to_shift() { Shift_Id = shiftId, Worker_Id = workerId });
            }
            return RedirectToAction("Shifts","Home");
        }
    }
}
