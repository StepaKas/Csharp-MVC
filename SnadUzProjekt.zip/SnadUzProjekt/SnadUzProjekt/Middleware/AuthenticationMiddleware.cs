﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SnadUzProjekt.Middleware
{
    public class AuthenticationMiddleware
    {
        private readonly RequestDelegate _next;

        public AuthenticationMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public Task Invoke(HttpContext httpContext)
        {
            var path = httpContext.Request.Path;
            if (path.HasValue && path.ToString() != "/" )
            {
                if (httpContext.Session.GetString("user") == null)
                {
                    httpContext.Response.Redirect("/");
                    return Task.CompletedTask;
                }
            }
            return _next(httpContext);
        }
    }
}
