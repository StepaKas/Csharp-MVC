﻿using AuctionSystem.ORM.Oracle;
using KonzolaCore.Database;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ProjektMVC.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ProjektMVC.Controllers
{
    
    public class HomeController : Controller
    {
        public static ICollection<Worker> workers = new List<Worker>();
        public GenericController genericControler = new GenericController();
        private Worker activeUser = new Worker();   

        public  HomeController(GenericController gc)
        {
            genericControler = gc;
      
        }
        public IActionResult Workers()
        {

            if (!CheckLogin())
            {

                return RedirectToAction("Login", "Home");
            }
            


            ViewBag.workers = workers;
            return View();
        }
        [HttpPost]
        public IActionResult Workers(string? Search)
        {
            if (!CheckLogin())
            {
                return RedirectToAction("Login", "Home");
            }
            if (Search == "" || Search == null)
            {
                return Workers();
            }
            ViewBag.workers = workers.Where(x => x.Name.Contains(Search));
            return View();
        }

        public IActionResult WorkerDetail(int Id)
        {
            if (!CheckLogin())
            {
                return RedirectToAction("Login", "Home");
            }

            ViewBag.worker = workers.Where(x => x.Id == Id).First();
            return View();
        }

        public async Task<IActionResult> WorkerDelete(int Id)
        {
            if (!CheckLogin())
            {
                return RedirectToAction("Login", "Home");
            }

            await genericControler.DeleteAsync(Id, new Worker { });
            workers = await genericControler.GetAllAsync(new Worker { });
            return View();
        }

        public async Task<IActionResult> WorkerUpdate(int Id)
        {
            if (!CheckLogin())
            {
                return RedirectToAction("Login", "Home");
            }


            var wor = workers.FirstOrDefault(x => x.Id == Id);
            ViewBag.worker = wor;
            return View(wor);
        }
        [HttpPost]
        public async Task<IActionResult> WorkerUpdate(Worker wor)
        {
           
            if (!CheckLogin())
            {
                return RedirectToAction("Login", "Home");
            }
            if (!(wor.Name != null && wor.Surname != null && wor.Email != null && wor.My_password != null && wor.Date_of_Birth != null && wor.Position != null && wor.Role != null))
            {
                var wor2 = workers.FirstOrDefault(x => x.Id == wor.Id);
                ViewBag.worker = wor2;
                return View();
            }
            await genericControler.UpdateAsync((int)wor.Id, wor);
            workers = await genericControler.GetAllAsync(new Worker { });
            ViewBag.worker = workers.FirstOrDefault(x => x.Id == wor.Id);
            return View();
        }
        public  IActionResult Index()
        {
            
            if (!CheckLogin())            {
                
                return RedirectToAction("Login", "Home");
                
            }
            var wor =  CurrentUser();
            ViewBag.UserName = wor.Name;
            ViewBag.UserLName = wor.Surname;
            ViewBag.UserRole = wor.Role;
            return View();
        }

        public IActionResult Login()
        {

            if (CheckLogin())
            {
                return RedirectToAction("Index", "Home");
            }
            return View();
        }

        public Worker CurrentUser()
        {
            
            if (this.HttpContext.Session.TryGetValue("user", out byte[] data2))
            {

                List<string> list = new List<string>();
                string txt = Encoding.UTF8.GetString(data2);
                if (txt == "")
                {
                    return new Worker { };
                }
                list = txt.Split(',').ToList();
                var wor = workers.FirstOrDefault(x => x.My_password == list[1] && x.Email == list[0]);

                return wor;
            }
            return new Worker { };

        }
        [HttpPost]
        public async Task<IActionResult> Login(Worker worker)
        {

            workers = await genericControler.GetAllAsync(new Worker { });
            var wor = workers.FirstOrDefault(x => x.My_password == worker.My_password && x.Email == worker.Email);
            if (wor != null)
            {
                activeUser = wor;
                var data = Encoding.UTF8.GetBytes($"{wor.Email},{wor.My_password}");
                this.HttpContext.Session.Set("user", data);
                return RedirectToAction("Index", "Home");
            }
            
            return View();
        }

        public IActionResult Logout()
        {
            activeUser = null;
            var data = Encoding.UTF8.GetBytes("");
            this.HttpContext.Session.Set("user", data);
            return RedirectToAction("Login", "Home");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public bool CheckLogin()
        {
            if (this.HttpContext.Session.TryGetValue("user", out byte[] data2))
            {

                List<string> list = new List<string>();
                string txt = Encoding.UTF8.GetString(data2);
                if (txt == "")
                {
                    return false;
                }
                list = txt.Split(',').ToList();
                activeUser = new Worker { Email = list[0], My_password = list[1] };

                return true;
            }
            return false;
        }

        public IActionResult GetJson()
        {

            if (!CheckLogin() )
            {

                return RedirectToAction("Login", "Home");

            }
            if (CurrentUser().Role != "Boss")
            {
                return RedirectToAction("NoRights", "Home");
            }
            return new JsonResult(workers);
        }

        public IActionResult NoRights()
        {

            if (!CheckLogin())
            {

                return RedirectToAction("Login", "Home");

            }
            return View();
        }
    }
}
